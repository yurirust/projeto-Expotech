
const mysql = require('mysql2');

const connection = mysql.createConnection({
  host: '127.0.0.1',
  user: 'gestor',
  password: '',
  database: 'sistema_gestao',
  port: 3306
});

connection.connect(err => {
  if (err) {
    console.error('Erro ao conectar ao MySQL:', err);
    process.exit();
  } else {
    console.log('Conectado ao MySQL!');
  }
});

module.exports = connection;
