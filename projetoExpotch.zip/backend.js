
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Cadastrar usuário
app.post('/usuarios', (req, res) => {
  const { login, senha } = req.body;
  const sql = 'INSERT INTO usuarios (login, senha) VALUES (?, ?)';
  db.query(sql, [login, senha], (err) => {
    if (err) {
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(400).send('Usuário já existe!');
      }
      return res.status(500).send(err);
    }
    res.send('Usuário cadastrado com sucesso!');
  });
});

// Login
app.post('/login', (req, res) => {
  const { login, senha } = req.body;
  const sql = 'SELECT * FROM usuarios WHERE login = ? AND senha = ?';
  db.query(sql, [login, senha], (err, results) => {
    if (err) return res.status(500).send(err);
    if (results.length > 0) res.send('Login válido');
    else res.status(401).send('Login ou senha inválidos!');
  });
});

// Obter ordens por usuário
app.get('/ordens/:usuario', (req, res) => {
  const sql = 'SELECT * FROM ordens WHERE usuario = ?';
  db.query(sql, [req.params.usuario], (err, results) => {
    if (err) return res.status(500).send(err);
    res.json(results);
  });
});

// Criar nova ordem
app.post('/ordens', (req, res) => {
  const { tipo, inicio, conclusao, usuario } = req.body;
  const sql = 'INSERT INTO ordens (tipo, inicio, conclusao, usuario) VALUES (?, ?, ?, ?)';
  db.query(sql, [tipo, inicio, conclusao, usuario], (err) => {
    if (err) return res.status(500).send(err);
    res.send('Ordem criada com sucesso!');
  });
});

// Excluir ordem
app.delete('/ordens/:id', (req, res) => {
  const sql = 'DELETE FROM ordens WHERE id = ?';
  db.query(sql, [req.params.id], (err) => {
    if (err) return res.status(500).send(err);
    res.send('Ordem excluída!');
  });
});

const PORT = 3000;
app.listen(PORT, () => console.log(`Servidor rodando em http://localhost:${PORT}`));
